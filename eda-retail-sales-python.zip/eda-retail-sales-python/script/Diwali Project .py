import pandas as pd
import seaborn as sns
from matplotlib import  pyplot as plt
import numpy as np

diwali_sales = pd.read_csv('Diwali Sales Data.csv' , encoding='unicode_escape')
diwali_sales
diwali_sales.shape
diwali_sales.head(10)
# to find data info
diwali_sales.info()
# to delete  unuseful column and save data
diwali_sales.drop(['Status','unnamed1'],axis=1 , inplace=True)
# recheck data info
diwali_sales.info()
# to check where is null values
pd.isnull(diwali_sales)
# check total no of null value
pd.isnull(diwali_sales).sum()
diwali_sales.shape
# drop null values
diwali_sales.dropna(inplace=True)
diwali_sales.shape
# to change amount column data type into intiger
diwali_sales['Amount']=diwali_sales['Amount'].astype('int')
# now check amount column data type
diwali_sales['Amount'].dtypes
# to check all column 
diwali_sales.columns
# to rename marital_status into shaadi
diwali_sales.rename(columns={'Marital_Status':'Shaadi'})
# find description of data frame
diwali_sales.describe()
# use describe on some column
diwali_sales[['Age','Orders','Amount']].describe()
diwali_sales.columns
# make count plot for gender column
ax= sns.countplot(x='Gender', data = diwali_sales)
for bars in ax.containers:
    ax.bar_label(bars)
# now group by gender ascending acc to amount and sum amount
diwali_sales.groupby(['Gender'],as_index = False)['Amount'].sum().sort_values(by='Amount',ascending=False)
# now make bar plot for above
sales_gen=diwali_sales.groupby(['Gender'],as_index = False)['Amount'].sum().sort_values(by='Amount',ascending=False)
sns.barplot(x='Gender',y='Amount',data=sales_gen)
# we see most of the buyers are females and purchasing power of females are greataer than male
# make count plot of age group
bx= sns.countplot(x='Age Group', data = diwali_sales , hue='Gender')
for bars in bx.containers:
    bx.bar_label(bars)
# now make bar plot for total amount vs age group
sales_age=diwali_sales.groupby(['Age Group'],as_index = False)['Amount'].sum().sort_values(by='Amount',ascending=False)
sns.barplot(x='Age Group',y='Amount',data=sales_age)
# from above 2 graphs we see that most of the buyers are of age group 26-35 are females
# now make bar plot for sates acc to sum of orders desc top 10 and set plot size 
sales_state=diwali_sales.groupby(['State'],as_index = False)['Orders'].sum().sort_values(by='Orders',ascending=False).head(10)
sns.set(rc={'figure.figsize':(20,5)})
sns.barplot(x='State',y='Orders',data=sales_state)
# make plot for state acc to amount desc top 10
sales_state_amount=diwali_sales.groupby(['State'],as_index = False)['Amount'].sum().sort_values(by='Amount',ascending=False).head(10)
sns.set(rc={'figure.figsize':(20,5)})
sns.barplot(x='State',y='Amount',data=sales_state_amount)
# we see from above 2 graphs that top 3 states who ordered most are UP , maharashtra, karnataka,....,Kerla,haryana,gujarat but puchase power of states are 
 # up,maharashtra.....haryana,gujrat,bihar
# make count plot for marital status
mx=sns.countplot(data=diwali_sales,x='Marital_Status')
for bars in mx.containers:
    mx.bar_label(bars)
mx=sns.countplot(data=diwali_sales,x='Marital_Status')
sns.set(rc={'figure.figsize':(2,5)})
for bars in mx.containers:
    mx.bar_label(bars)
# make plot for marital status
sales_marital_status=diwali_sales.groupby(['Marital_Status' , 'Gender'],as_index = False)['Amount'].sum().sort_values(by='Amount',ascending=False)
sns.set(rc={'figure.figsize':(6,5)})
sns.barplot(x='Marital_Status',y='Amount',data=sales_marital_status,hue='Gender')
# we see from above 2 graphs that married women are more buyer and have more purchasing power
# make plot for occupation
acx=sns.countplot(data=diwali_sales,x='Occupation')
sns.set(rc={'figure.figsize':(25,5)})
for bars in acx.containers:
    acx.bar_label(bars)
# make plot for occupation
sales_occ=diwali_sales.groupby(['Occupation'],as_index = False)['Amount'].sum().sort_values(by='Amount',ascending=False)
sns.set(rc={'figure.figsize':(25,5)})
sns.barplot(x='Occupation',y='Amount',data=sales_occ)
# from above 2 graphs we see that most of the buyers working in it , health , aviation
# make plot for Product_Category 
px=sns.countplot(data=diwali_sales,x='Product_Category')
sns.set(rc={'figure.figsize':(17,5)})
for bars in px.containers:
    px.bar_label(bars)
sales_pc=diwali_sales.groupby(['Product_Category'],as_index = False)['Amount'].sum().sort_values(by='Amount',ascending=False).head(10)
sns.set(rc={'figure.figsize':(20,5)})
sns.barplot(x='Product_Category',y='Amount',data=sales_pc)
# the most sold product are food, clotting , electronics
# fro product id
sales_id=diwali_sales.groupby(['Product_ID'],as_index = False)['Orders'].sum().sort_values(by='Orders',ascending=False).head(10)
sns.set(rc={'figure.figsize':(20,5)})
sns.barplot(x='Product_ID',y='Orders',data=sales_id)
# or
sales_id = plt.subplots(figsize=(12,7))
diwali_sales.groupby('Product_ID')['Orders'].sum().nlargest(10).sort_values(ascending=False).plot(kind='bar')
# Conclusion : Married women are age group 26-35 yrs from UP , Maharashtra and Karnataka working in IT , healthcare and aviation are more likely to buy products from food , clothing and electronics category.
%history -f main1.py
